package View;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageButton;

import com.example.lyrical.R;

public class MainActivity extends AppCompatActivity {

    EditText edtxsearch;
    ImageButton imgbtsearch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtxsearch = findViewById(R.id.edtxsearch);
        imgbtsearch = findViewById(R.id.imgbtsearch);


    }
}