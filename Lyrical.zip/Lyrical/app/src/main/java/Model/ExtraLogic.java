package Model;

public class ExtraLogic {
}
